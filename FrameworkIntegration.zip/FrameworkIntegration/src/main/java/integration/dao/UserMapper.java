package integration.dao;

import integration.bean.MlqUser;
import org.apache.ibatis.annotations.Param;

public interface UserMapper {

    /**
     * 用户登录验证
     * @param name
     * @param pwd
     * @return
     */
    public MlqUser UserLogin(@Param("userName")String name,@Param("userPwd")String pwd);



}
