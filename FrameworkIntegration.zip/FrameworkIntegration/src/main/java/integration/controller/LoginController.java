package integration.controller;

import integration.bean.MlqUser;
import integration.service.UserMapperService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class LoginController {

    //声明Service
    @Resource
    private UserMapperService userMapperService;

    //参数可以是数组@RequestMapping({"/welcome","/welcom"})
    @RequestMapping("/login")
    public String login()
    {
        return "login";
    }
    @RequestMapping(value = "/dologin",method = RequestMethod.POST)
    public String doLogin(@RequestParam String userName,
                          @RequestParam String userPwd,
                          HttpServletRequest request,
                          HttpSession session)
    {
        System.out.println("Controller中转器：用户名："+userName+"---密码："+userPwd);
       MlqUser mlqUser = (MlqUser)userMapperService.UserLogin(userName, userPwd);
        if(mlqUser!=null){
            session.setAttribute("UserInfo",mlqUser);
            return "redirect:/sys/main";
        }
        request.setAttribute("error","用户名或密码不正确！！！");
        return "/login";
    }

    //登录主页面跳转
    @RequestMapping("/sys/main")
    public String main()
    {
        return "main";
    }
    @RequestMapping("/logout")
    public String logout(HttpSession session)
    {
        session.invalidate();
        System.out.println("强制退出！！！");
        return "login";
    }
}
