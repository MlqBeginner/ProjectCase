package integration.service.impl;

import integration.bean.MlqUser;
import integration.dao.UserMapper;
import integration.service.UserMapperService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

@Service
public class UserMapperServiceImpl implements UserMapperService {

    @Resource(name = "userMapper")
    private UserMapper userMapper;

    public MlqUser UserLogin(String name, String pwd) {
        return userMapper.UserLogin(name,pwd);
    }
}
