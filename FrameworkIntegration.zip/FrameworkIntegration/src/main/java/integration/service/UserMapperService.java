package integration.service;

import integration.bean.MlqUser;
import org.apache.ibatis.annotations.Param;

public interface UserMapperService {


    /**
     * 用户登录验证
     * @param name
     * @param pwd
     * @return
     */
    public MlqUser UserLogin(@Param("name")String name, @Param("pwd")String pwd);
}
