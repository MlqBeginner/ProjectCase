package mlq.service;

import com.github.pagehelper.PageInfo;
import mlq.bean.TestClass;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author MLQ
 * @Git https://github.com/MlqBeginner
 * @create 2018-08-28 16:34
 **/
public interface TestClassMapperService {

    /**
     * 查询所有信息
     */
    public PageInfo<TestClass> allList(Integer pageNum,String ReverseOrder,String positive);
}
