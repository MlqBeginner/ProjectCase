package mlq.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import mlq.bean.TestClass;
import mlq.mapper.TestClassMapper;
import mlq.service.TestClassMapperService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author MLQ
 * @Git https://github.com/MlqBeginner
 * @create 2018-08-28 16:34
 **/
@Service
public class TestClassMapperServiceImpl implements TestClassMapperService {

    @Resource
    private TestClassMapper testClassMapper;


    @Override
    public PageInfo<TestClass> allList(Integer pageNum,String reverseOrder,String positive) {
        /**
         * pageSize：页大小
         * pageNum:当前页数
         */
        Page<TestClass> page = PageHelper.startPage(pageNum, 10);
        System.out.println(reverseOrder+"======"+positive);
        List<TestClass> testClasses = testClassMapper.allList(reverseOrder,positive);
        return page.toPageInfo();
    }
}
