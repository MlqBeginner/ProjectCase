package mlq.mapper;

import mlq.bean.TestClass;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author MLQ
 * @Git https://github.com/MlqBeginner
 * @create 2018-08-28 16:33
 **/
@Repository
public interface TestClassMapper {

    /**
     * 查询所有信息
     */
    public List<TestClass> allList(@Param("desc")String ReverseOrder,@Param("asc")String positive);

}
