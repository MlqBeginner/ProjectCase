package mlq.bean;


import java.io.Serializable;

public class TestClass implements Serializable {

  private String column1;
  private Integer column2;
  private String column3;

  @Override
  public String toString() {
    return "TestClass{" +
            "column1='" + column1 + '\'' +
            ", column2=" + column2 +
            ", column3='" + column3 + '\'' +
            '}';
  }

  public String getColumn1() {
    return column1;
  }

  public void setColumn1(String column1) {
    this.column1 = column1;
  }


  public Integer getColumn2() {
    return column2;
  }

  public void setColumn2(Integer column2) {
    this.column2 = column2;
  }


  public String getColumn3() {
    return column3;
  }

  public void setColumn3(String column3) {
    this.column3 = column3;
  }

}
