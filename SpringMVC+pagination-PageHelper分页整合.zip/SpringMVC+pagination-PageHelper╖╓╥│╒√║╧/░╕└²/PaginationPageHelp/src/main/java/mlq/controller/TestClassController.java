package mlq.controller;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import mlq.bean.TestClass;
import mlq.service.TestClassMapperService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * ${DESCRIPTION}
 *
 * @author MLQ
 * @Git https://github.com/MlqBeginner
 * @create 2018-08-28 16:34
 **/
@Controller
public class TestClassController {

    @Resource
    private TestClassMapperService testClassMapperService;

    @RequestMapping(value = "/index")
    @ResponseBody
    public void allLists(Integer pageNum,
                         String ReverseOrder,
                         String positive,
                         HttpServletResponse response) throws IOException {
        PageInfo<TestClass> pageInfo = testClassMapperService.allList(pageNum,ReverseOrder,positive);
        response.setCharacterEncoding("utf-8");
        String s = JSON.toJSONString(pageInfo);
        response.getWriter().write(s);
    }

}
