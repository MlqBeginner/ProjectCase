package integrationDemo1.text;

import integrationDemo1.dao.MlqUserDao;
import integrationDemo1.entity.MlqUser;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class MlqUserDemo {

    @Test
    public void allUserList()
    {
        //伪造用户对象
        MlqUser mlqUser=new MlqUser(20180001,"MLQ","123","马立强");
        //实例ApplicationContext
        ApplicationContext context=
                new ClassPathXmlApplicationContext("integrationDemo1.xml");
        //获取实例对象
        MlqUserDao userMapper = (MlqUserDao) context.getBean("userMapper");
        //调用方法查询信息
        System.out.println(mlqUser.getUserName());
        List<MlqUser> mlqUsers = userMapper.allList(mlqUser);
        for (MlqUser item : mlqUsers)
        {
            System.out.println("用户名："+item.getUserName());
        }
    }





}
