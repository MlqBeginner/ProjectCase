package mlq.bean;


public class User {

  private Integer uId;
  private String userName;
  private String userPwd;
  private String realName;
  private String picPath;
  private String picPathTow;

    public String getPicPathTow() {
        return picPathTow;
    }

    public void setPicPathTow(String picPathTow) {
        this.picPathTow = picPathTow;
    }

    public User() {
  }

  public User(Integer uId, String userName, String userPwd, String realName, String picPath, String picPathTow) {
    this.uId = uId;
    this.userName = userName;
    this.userPwd = userPwd;
    this.realName = realName;
    this.picPath = picPath;
    this.picPathTow = picPathTow;
  }

  @Override
  public String toString() {
    return "User{" +
            "uId=" + uId +
            ", userName='" + userName + '\'' +
            ", userPwd='" + userPwd + '\'' +
            ", realName='" + realName + '\'' +
            ", picPath='" + picPath + '\'' +
            ", picPathTow='" + picPathTow + '\'' +
            '}';
  }

  public Integer getuId() {
    return uId;
  }

  public void setuId(Integer uId) {
    this.uId = uId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getUserPwd() {
    return userPwd;
  }

  public void setUserPwd(String userPwd) {
    this.userPwd = userPwd;
  }

  public String getRealName() {
    return realName;
  }

  public void setRealName(String realName) {
    this.realName = realName;
  }

  public String getPicPath() {
    return picPath;
  }

  public void setPicPath(String picPath) {
    this.picPath = picPath;
  }
}
