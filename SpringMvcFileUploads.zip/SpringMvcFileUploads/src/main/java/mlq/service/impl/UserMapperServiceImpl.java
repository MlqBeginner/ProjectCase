package mlq.service.impl;

import mlq.bean.User;
import mlq.mapper.UserMapper;
import mlq.service.UserMapperService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

@Service("userMapperServiceImpl")
public class UserMapperServiceImpl implements UserMapperService {

    @Resource(name = "userMapper")
    private UserMapper userMapper;

    public boolean addUser(User user) {
        return (userMapper.addUser(user) > 0) ? true : false;
    }



}
