package mlq.service;

import mlq.bean.User;

public interface UserMapperService {

    /**
     * 添加用户
     * @param user
     * @return
     */
    public boolean addUser(User user);

}
