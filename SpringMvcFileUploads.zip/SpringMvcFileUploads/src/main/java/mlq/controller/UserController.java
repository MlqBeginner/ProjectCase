package mlq.controller;

import mlq.bean.User;
import mlq.service.UserMapperService;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;

@Controller
public class UserController {

    @Resource(name = "userMapperServiceImpl")
    private UserMapperService userMapperService;
    /**
     * 跳转到添加页面
     *
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String add() {
        return "addUser";
    }

    /**
     *执行添加操作
     * @param session
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String addSave(HttpSession session, HttpServletRequest
                          request,@RequestParam(value = "picPath",required = false) MultipartFile[] picPath) {
        System.out.println("我已经进来POST-ADD------------------------");
        User user=new User();
        user.setUserName(request.getParameter("userName"));
        user.setUserPwd(request.getParameter("userPwd"));
        user.setRealName(request.getParameter("realName"));
        //当前文件路径
        String picFilePath="";
        for (int i = 0; i <picPath.length; i++) {
            //判断文件是否为空
            if (!picPath[i].isEmpty()) {
                //上传文件的存储路径（服务器文件系统上的绝对文件路径）
                String uploadFilePath = request.getSession().getServletContext().getRealPath("/upload/");
                File filePath = new File(uploadFilePath);
                //判断文件或目录是否存在：若不存在则创建该目录
                if (!filePath.exists()) {
                    //创建此抽象路径名指定的目录，包括所有必需但不存在的父目录。
                    filePath.mkdirs();
                }
                //获取源文件名
                String oldFileName = picPath[i].getOriginalFilename();
                //获取源文件后缀名
                String prefix = FilenameUtils.getExtension(oldFileName);
                //设置文件大小
                Integer fileSize = 500000;
                //上传文件大小不得超过500KB
                if (picPath[i].getSize() > fileSize) {
                    System.out.println("上传终止：当前上传的文件大于500KB！！！");
                    return "addUser";

                }//图片格式验证
                else if (prefix.equalsIgnoreCase("jpg") ||
                        prefix.equalsIgnoreCase("png") ||
                        prefix.equalsIgnoreCase("jpeg") ||
                        prefix.equalsIgnoreCase("pneg")) {
                    String fileName = System.currentTimeMillis() + RandomUtils.nextInt(0, 1000000) + oldFileName;
                    File file = new File(uploadFilePath, fileName);
                    try {
                        picPath[i].transferTo(file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    picFilePath = uploadFilePath + fileName;
                } else {
                    System.out.println("上传终止：当前文件格式不正确！！！");
                    return "addUser";
                }
                if(i==0) {
                    user.setPicPath(picFilePath);
                }else if (i==1)
                {
                    user.setPicPathTow(picFilePath);
                }
            }
        }
        if (userMapperService.addUser(user))
        {
            System.out.println("当前文件符合所有定义要求：上传成功>>>>>>");
            System.out.println("当前文件上传路径为："+picFilePath);
            return "index";
        }else {
            System.out.println("当前文件符合所有定义要求：上传失败>>>>>>");
            return "addUser";
        }
    }

}
