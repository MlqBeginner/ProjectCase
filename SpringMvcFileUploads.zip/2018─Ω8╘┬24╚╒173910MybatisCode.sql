/*
SQLyog v10.2 
MySQL - 5.5.44 : Database - MyBatisCode
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`MyBatisCode` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `MyBatisCode`;

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `uId` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `userName` varchar(50) COLLATE utf8_turkish_ci NOT NULL COMMENT '用户名',
  `userPwd` varchar(50) COLLATE utf8_turkish_ci NOT NULL COMMENT '用户密码',
  `realName` varchar(50) COLLATE utf8_turkish_ci NOT NULL COMMENT '登陆后显示',
  PRIMARY KEY (`uId`)
) ENGINE=InnoDB AUTO_INCREMENT=20180028 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

/*Data for the table `user` */

LOCK TABLES `user` WRITE;

insert  into `user`(`uId`,`userName`,`userPwd`,`realName`) values (20180001,'MLQMLQ','123','MLQMLQ'),(20180002,'FKX','123','范可新'),(20180003,'FKX','123','王康'),(20180004,'YJY','123','杨婧源'),(20180005,'LSY','123','马立强'),(20180020,'YJY','123','杨婧源A'),(20180021,'YJY','123','杨婧源A'),(20180022,'1','2','3'),(20180023,'111','22','222'),(20180024,'ssacs','sdasd','sdas'),(20180025,'MLQ','sadasd','dasd'),(20180026,'sdgsd','fsdfs','dfsdf'),(20180027,'','qqq','qqq');

UNLOCK TABLES;

/*Table structure for table `userDemo1` */

DROP TABLE IF EXISTS `userDemo1`;

CREATE TABLE `userDemo1` (
  `uId` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `userName` varchar(50) COLLATE utf8_turkish_ci NOT NULL COMMENT '用户名',
  `userPwd` varchar(50) COLLATE utf8_turkish_ci NOT NULL COMMENT '用户密码',
  `realName` varchar(50) COLLATE utf8_turkish_ci NOT NULL COMMENT '登陆后显示',
  `PicPath` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '用户头像文件',
  PRIMARY KEY (`uId`)
) ENGINE=InnoDB AUTO_INCREMENT=20180033 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

/*Data for the table `userDemo1` */

LOCK TABLES `userDemo1` WRITE;

insert  into `userDemo1`(`uId`,`userName`,`userPwd`,`realName`,`PicPath`) values (20180001,'MLQMLQ','123','MLQMLQ',NULL),(20180002,'FKX','123','范可新',NULL),(20180003,'FKX','123','王康',NULL),(20180004,'YJY','123','杨婧源',NULL),(20180030,'FANKEXIN','mlq123456','sdsd',NULL),(20180031,'FANKEXIN','mlq123456','2222','D:\\ideaIU-2017.3.4\\SSMCourseTows\\SpringMvcFileUploads\\target\\SpringFormLabels-1.0-SNAPSHOT\\upload1535085865184t01c031b1cf71e248cb.jpg'),(20180032,'FANKEXIN','1','1111','D:\\ideaIU-2017.3.4\\SSMCourseTows\\SpringMvcFileUpload\\target\\SpringFormLabels-1.0-SNAPSHOT\\upload1535095824099t01c031b1cf71e248cb.jpg');

UNLOCK TABLES;

/*Table structure for table `userDemo2` */

DROP TABLE IF EXISTS `userDemo2`;

CREATE TABLE `userDemo2` (
  `uId` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `userName` varchar(50) COLLATE utf8_turkish_ci NOT NULL COMMENT '用户名',
  `userPwd` varchar(50) COLLATE utf8_turkish_ci NOT NULL COMMENT '用户密码',
  `realName` varchar(50) COLLATE utf8_turkish_ci NOT NULL COMMENT '登陆后显示',
  `PicPath` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '用户头像文件',
  `PicPathTow` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '用户头像文件Tow',
  PRIMARY KEY (`uId`)
) ENGINE=InnoDB AUTO_INCREMENT=20180032 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

/*Data for the table `userDemo2` */

LOCK TABLES `userDemo2` WRITE;

insert  into `userDemo2`(`uId`,`userName`,`userPwd`,`realName`,`PicPath`,`PicPathTow`) values (20180001,'MLQMLQ','123','MLQMLQ',NULL,NULL),(20180002,'FKX','123','范可新',NULL,NULL),(20180003,'FKX','123','王康',NULL,NULL),(20180004,'YJY','123','杨婧源',NULL,NULL),(20180030,'FANKEXIN','mlq123456','sdsd',NULL,NULL),(20180031,'MLQ','mlq123456','sdsd','D:\\ideaIU-2017.3.4\\SSMCourseTows\\SpringMvcFileUploads\\target\\SpringFormLabels-1.0-SNAPSHOT\\upload1535103034665t01c031b1cf71e248cb.jpg','D:\\ideaIU-2017.3.4\\SSMCourseTows\\SpringMvcFileUploads\\target\\SpringFormLabels-1.0-SNAPSHOT\\upload1535102940893t0168ad80cee23fcea2.jpg');

UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
