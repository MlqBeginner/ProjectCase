package dataAndFormat.controller;

import org.springframework.beans.propertyeditors.CustomBooleanEditor;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 使用@InitBinder装配自定义编辑器
 */
public class BaseController {
    /**
     * 在服务器启动的时候就会加载该方法
     * @param webDataBinder
     */
    @InitBinder
    public void initBinder(WebDataBinder webDataBinder)
    {
        System.out.println("InitBinder装配自定义编辑器父级的我被加载了------------");
        webDataBinder.registerCustomEditor
                (Date.class,new CustomDateEditor(
                        new SimpleDateFormat("yyyy-MM-dd"),true));
    }
}
