package dataAndFormat.controller;

import dataAndFormat.entity.MlqUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

@Controller
public class IndexController extends BaseController {

    //参数可以是数组@RequestMapping({"/welcome","/welcom"})
    @RequestMapping(value="/welcome",method = RequestMethod.GET,params ="userName")
    public ModelAndView welcome(@RequestParam String userName)
    {
        System.out.println("GET我是通过请求参数进行映射：传递与视图解析器："+userName);
        System.out.println("我正在测试使用InitBinder装配自定义编辑器完成日期格式转换..............");
        return new ModelAndView("index");
    }

}
