package dataAndFormat.tools;

import org.springframework.core.convert.converter.Converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringToDateConverter implements Converter<String,Date> {

    private String datepatten;

    public StringToDateConverter(String datepatten) {
        System.out.println("123-------------");
        this.datepatten = datepatten;
    }

    public Date convert(String s) {
        Date date=null;
        try {
            date=new SimpleDateFormat(datepatten).parse(s);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        System.out.println(date+"+++++++");
        return date;
    }
}
