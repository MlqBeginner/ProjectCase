package mlq.service;

import mlq.bean.User;

public interface UserMapperService {

    /**
     * 添加用户
     * @param user
     * @return
     */
    public boolean addUser(User user);

    /**
     * 修改用户信息
     * @param user
     * @return
     */
    public boolean updUser(User user);

    /**
     * 查询单个用户
     * @param id
     * @return
     */
    public User getUser(String id);
}
