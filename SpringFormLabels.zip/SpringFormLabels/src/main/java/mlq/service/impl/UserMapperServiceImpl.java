package mlq.service.impl;

import mlq.bean.User;
import mlq.mapper.UserMapper;
import mlq.service.UserMapperService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

@Service
public class UserMapperServiceImpl implements UserMapperService {

    @Resource(name = "userMapper")
    private UserMapper userMapper;

    public UserMapper getUserMapper() {
        return userMapper;
    }
    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    public boolean addUser(User user) {
        return (userMapper.addUser(user) > 0) ? true : false;
    }

    public boolean updUser(User user) {
        return (userMapper.updUser(user))>0?true:false;
    }

    public User getUser(String id) {
        return userMapper.getUser(id);
    }


}
