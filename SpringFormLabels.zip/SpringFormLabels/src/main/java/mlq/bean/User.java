package mlq.bean;

import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;

public class User {

  private Integer uId;
  @NotNull(message = "用户名不能为空")
  private String userName;
  @Length(max = 6,min = 2,message = "长度........")
  private String userPwd;
  @NotNull(message = "真实姓名不能为空")
  private String realName;

  public Integer getuId() {
    return uId;
  }

  public void setuId(Integer uId) {
    this.uId = uId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }


  public String getUserPwd() {
    return userPwd;
  }

  public void setUserPwd(String userPwd) {
    this.userPwd = userPwd;
  }


  public String getRealName() {
    return realName;
  }

  public void setRealName(String realName) {
    this.realName = realName;
  }

}
