package mlq.controller;

import mlq.bean.User;
import mlq.service.UserMapperService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
public class UserController {

    @Resource
    private UserMapperService userMapperService;

    public UserMapperService getUserMapperService() {
        return userMapperService;
    }

    public void setUserMapperService(UserMapperService userMapperService) {
        this.userMapperService = userMapperService;
    }

    /**
     * 跳转到添加页面
     *
     * @param user
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String add(@ModelAttribute("user") User user) {
        return "addUser";
    }
    
    /**
     *执行添加操作
     * @param user
     * @param bindingResult
     * @param session
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String addSave(@Valid User user,BindingResult bindingResult, HttpSession session) {
        //判断是否有错误
        if(bindingResult.hasErrors())
        {
            System.out.println("JSR303出现了错误！！！");
            return "addUser";
        }
        if (userMapperService.addUser(user)) {
            return "index";
        }
        return "addUser";
    }

    /**
     * 修改页面跳转
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/modify", method = RequestMethod.GET)
    public String modify(@RequestParam("id")String id, Model model) {
        User user=userMapperService.getUser(id);
        model.addAttribute(user);
        return "modifyUser";
    }
    /**
     * 修改保存
     * @return
     */
    @RequestMapping(value = "/modify", method = RequestMethod.POST)
    public String modifySave(@Valid User user,BindingResult bindingResult) {
        //判断是否满足数据验证
        if(bindingResult.hasErrors())
        {
            System.out.println("JSR303出现了错误！！！");
            return "modifyUser";
        }
        if (userMapperService.updUser(user))
        {
            System.out.println("修改成功---------------------");
            return "index";
        }
        return "index";
    }
}
