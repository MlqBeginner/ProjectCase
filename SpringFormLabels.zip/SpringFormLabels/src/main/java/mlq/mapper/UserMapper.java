package mlq.mapper;

import mlq.bean.User;

public interface UserMapper {

    /**
     * 添加用户
     * @param user
     * @return
     */
    public int addUser(User user);

    /**
     * 修改用户信息
     * @param user
     * @return
     */
    public int updUser(User user);

    /**
     * 查询单个用户
     * @param id
     * @return
     */
    public User getUser(String id);

}
