

$(function () {
    $("#btn").click(function () {
        if ($("#UserId").val()==null&&$("#UserId").val()=="")
        {
            alert("请输入要修该的用户ID！！！")
            return;
        }
        window.location.href="modify?id="+$("#UserId").val();
    });
});