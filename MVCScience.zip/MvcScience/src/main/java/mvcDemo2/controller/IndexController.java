package mvcDemo2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class IndexController{

    @RequestMapping("/index")
    public ModelAndView showView()
    {
        System.out.println("我是使用注解方式实现的MVC");
        return new ModelAndView("index");
    }

}
