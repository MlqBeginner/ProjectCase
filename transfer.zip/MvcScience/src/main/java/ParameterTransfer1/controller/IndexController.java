package ParameterTransfer1.controller;

import ParameterTransfer1.entity.MlqUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

@Controller
public class IndexController {

    //参数可以是数组@RequestMapping({"/welcome","/welcom"})
    @RequestMapping(value="/welcome",method = RequestMethod.GET,params ="userName")
    public ModelAndView welcome(@RequestParam String userName)
    {
        System.out.println("GET我是通过请求参数进行映射：传递与视图解析器："+userName);
        return new ModelAndView("index");
    }
    //参数可以是数组@RequestMapping({"/welcome","/welcom"})
    @RequestMapping(value="/welcome",method = RequestMethod.POST,params ="userName")
    public ModelAndView welcome1(@RequestParam String userName)
    {
        System.out.println("POST我是通过请求参数进行映射：传递与视图解析器："+userName);
        return new ModelAndView("index");
    }

    //--------------------------解决参数是否必须问题--------------------------//
    //参数可以是数组@RequestMapping({"/welcome","/welcom"})
    @RequestMapping(value="/welcom2",method = RequestMethod.GET)
    public ModelAndView welcome2(@RequestParam(value ="userName",required =false) String userName)
    {
        System.out.println("GET我是通过请求参数进行映射：传递与视图解析器："+userName);
        return new ModelAndView("index");
    }

    //-------------------------将模型数据传给视图:ModelAndView--------------------------------//
    @RequestMapping(value="/welcome3",method = RequestMethod.GET)
    public ModelAndView welcome3(@RequestParam(value ="userName",required =false)String userName)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.addObject("userName",userName);
        modelAndView.setViewName("index");
        System.out.println("将模型数据传给视图:"+userName);
        return modelAndView;
    }
    //-------------------------将模型数据传给视图:Model--------------------------------//
    @RequestMapping(value="/welcome4",method = RequestMethod.GET)
    public String welcome4(@RequestParam(value ="userName",required =false)String userName,Model model)
    {
        //指定键获取
        model.addAttribute("userName",userName);
        //不指定键,按内置类型获取
        model.addAttribute(userName);
        //自定义类型
        MlqUser mlqUser=new MlqUser();
        mlqUser.setUserName(userName+"自定义");
        model.addAttribute(mlqUser);
        //通过键获取
        model.addAttribute("info",mlqUser);
        return "index";
    }

    //-------------------------Map作为处理方法入参：--------------------------------//
    @RequestMapping("/welcome5")
    public String welcome5(@RequestParam(value ="userName",required =false)String userName,Map<String,Object> objectMap)
    {
        objectMap.put("userName",userName);
        return "index";
    }

}
