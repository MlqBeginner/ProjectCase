package ParameterTransfer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class IndexController {

    //参数可以是数组@RequestMapping({"/welcome","/welcom"})
    @RequestMapping({"/welcome","/welcom"})
    public ModelAndView welcome(@RequestParam String userName)
    {
        System.out.println("我是参数传递与视图解析器："+userName);
        return new ModelAndView("index");
    }

}
