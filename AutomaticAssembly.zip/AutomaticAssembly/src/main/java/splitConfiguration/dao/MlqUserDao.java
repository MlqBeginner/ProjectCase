package splitConfiguration.dao;

import splitConfiguration.entity.MlqUser;

import java.util.List;

/**
 * 用户接口
 */
public interface MlqUserDao {

    /**
     * 查询所有用户列表信息
     * @param mlqUser
     * @return
     */
    public List<MlqUser> allList(MlqUser mlqUser);

    /**
     * 添加单个用户信息
     * @param mlqUser
     * @return
     */
    public int addUser(MlqUser mlqUser);

    /**
     * 添加多个用户信息
     * @param mlqUsers
     * @return
     */
    public void addUsers(List<MlqUser> mlqUsers);


}
