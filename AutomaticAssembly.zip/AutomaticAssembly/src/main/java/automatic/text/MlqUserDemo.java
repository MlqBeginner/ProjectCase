package automatic.text;

import automatic.entity.MlqUser;
import automatic.service.SveMlqUserDao;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.List;

public class MlqUserDemo {

    //------------------------------查询用户信息：自动装配：按名称-----------------------------------//
    @Test
    public void allUserList()
    {
        //伪造用户对象
        MlqUser mlqUser=new MlqUser(20180001,"MLQ","123","马立强");
        //实例ApplicationContext
        ApplicationContext context=
                new ClassPathXmlApplicationContext("automatic.xml");
        //输出所有BeanId名称
        String[] beanDefinitionNames = context.getBeanDefinitionNames();
        for (String item:beanDefinitionNames
                ) {
            System.out.println(item);
        }
        //获取实例对象
        SveMlqUserDao userMapper = (SveMlqUserDao)context.getBean("sveMlqUserDaoImpl");
        //调用方法查询信息
        List<MlqUser> mlqUsers = userMapper.allList(mlqUser);
        for (MlqUser item : mlqUsers)
        {
            System.out.println("用户名："+item.getUserName());
        }
    }
    //------------------------------查询用户信息：自动装配：按类型----------------------------------//
    @Test
    public void allUserList1()
    {
        //伪造用户对象
        MlqUser mlqUser=new MlqUser(20180001,"MLQ","123","马立强");
        //实例ApplicationContext
        ApplicationContext context=
                new ClassPathXmlApplicationContext("automatic.xml");
        //输出所有BeanId名称
        String[] beanDefinitionNames = context.getBeanDefinitionNames();
        for (String item:beanDefinitionNames
                ) {
            System.out.println(item);
        }
        //获取实例对象
        SveMlqUserDao userMapper = (SveMlqUserDao)context.getBean("sveMlqUserDaoImpla");
        //调用方法查询信息
        List<MlqUser> mlqUsers = userMapper.allList(mlqUser);
        for (MlqUser item : mlqUsers)
        {
            System.out.println("用户名："+item.getUserName());
        }
    }
}
