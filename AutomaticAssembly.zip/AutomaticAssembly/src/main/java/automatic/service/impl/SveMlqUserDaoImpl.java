package automatic.service.impl;

import automatic.dao.MlqUserDao;
import automatic.entity.MlqUser;
import automatic.service.SveMlqUserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 写在类上面，便是全局添加事务控制，所有方法都可以使用
 * @Transactional(propagation = Propagation.REQUIRED)
 */
//@Transactional(propagation = Propagation.REQUIRED)
@Service("sveMlqUserDaoImpl")
public class SveMlqUserDaoImpl implements SveMlqUserDao
{
    private MlqUserDao mlqUserDao;

    public MlqUserDao getMlqUserDao() {
        return mlqUserDao;
    }

    public void setMlqUserDao(MlqUserDao mlqUserDao) {
        this.mlqUserDao = mlqUserDao;
    }

    public List<MlqUser> allList(MlqUser mlqUser) {
        return mlqUserDao.allList(mlqUser);
    }

    public int addUser(MlqUser mlqUser) {
        return mlqUserDao.addUser(mlqUser);
    }

    /**
     * 使用注解方式添加事务机制
     * 方法上添加事务表示只能当前方法可以使用
     * 这里可以手动抛出异常来判断多条数据是否全部成功，或者全部失败
     * @param mlqUsers
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public void addUsers(List<MlqUser> mlqUsers) {
        for (MlqUser user: mlqUsers
             ) {
            addUser(user);
            //throw new RuntimeException("手动抛出异常验证多条数据是否插入成功还是失败：请验证数据库中的数据");
        }
    }

}
