package injectionMapper1.dao;

import injectionMapper1.entity.MlqUser;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 用户接口
 */
public interface MlqUserDao {

    /**
     * 查询所有用户列表信息
     * @param mlqUser
     * @return
     */
    public List<MlqUser> allList(MlqUser mlqUser);




}
