package injectionMapper2.dao.impl;

import injectionMapper2.dao.MlqUserDao;
import injectionMapper2.entity.MlqUser;
import org.springframework.stereotype.Repository;

import java.util.List;
public class MlqUserDaoImpl implements MlqUserDao {

    public List<MlqUser> allList(MlqUser mlqUser) {
        return null;
    }
}
