package injectionMapper2.service;

import injectionMapper2.entity.MlqUser;

import java.util.List;

/**
 * 用户接口
 */
public interface SveMlqUserDao {

    /**
     * 查询所有用户列表信息
     * @param mlqUser
     * @return
     */
    public List<MlqUser> allList(MlqUser mlqUser);




}
