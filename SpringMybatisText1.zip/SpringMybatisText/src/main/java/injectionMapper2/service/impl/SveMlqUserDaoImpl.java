package injectionMapper2.service.impl;

import injectionMapper2.dao.MlqUserDao;
import injectionMapper2.entity.MlqUser;
import injectionMapper2.service.SveMlqUserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service("sveMlqUserDaoImpl")
public class SveMlqUserDaoImpl implements SveMlqUserDao {

    @Autowired
    @Qualifier("mlqUserDao")
    private MlqUserDao mlqUserDao;

    public MlqUserDao getMlqUserDao() {
        return mlqUserDao;
    }

    public void setMlqUserDao(MlqUserDao mlqUserDao) {
        this.mlqUserDao = mlqUserDao;
    }

    public List<MlqUser> allList(MlqUser mlqUser) {
        System.out.println(mlqUserDao);
        return mlqUserDao.allList(mlqUser);
    }

}
