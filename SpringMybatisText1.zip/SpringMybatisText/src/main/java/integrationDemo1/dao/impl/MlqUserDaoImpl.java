package integrationDemo1.dao.impl;

import integrationDemo1.dao.MlqUserDao;
import integrationDemo1.entity.MlqUser;
import org.mybatis.spring.SqlSessionTemplate;

import java.util.List;

public class MlqUserDaoImpl implements MlqUserDao {

    private SqlSessionTemplate sqlSessionTemplate;

    public SqlSessionTemplate getSqlSessionTemplate() {
        return sqlSessionTemplate;
    }

    public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
        this.sqlSessionTemplate = sqlSessionTemplate;
    }

    public List<MlqUser> allList(MlqUser mlqUser) {
        List<MlqUser> allList =
                sqlSessionTemplate.selectList("integrationDemo1.dao.MlqUserDao.allList",mlqUser);
        return allList;
    }

}
