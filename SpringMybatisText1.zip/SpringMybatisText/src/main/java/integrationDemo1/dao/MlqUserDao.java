package integrationDemo1.dao;

import integrationDemo1.entity.MlqUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 用户接口
 */
public interface MlqUserDao {

    /**
     * 查询所有用户列表信息
     * @param mlqUser
     * @return
     */
    public List<MlqUser> allList(MlqUser mlqUser);




}
