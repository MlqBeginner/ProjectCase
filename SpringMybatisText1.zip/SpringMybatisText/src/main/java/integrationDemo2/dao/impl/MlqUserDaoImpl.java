package integrationDemo2.dao.impl;

import integrationDemo2.dao.MlqUserDao;
import integrationDemo2.entity.MlqUser;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.util.List;

public class MlqUserDaoImpl extends SqlSessionDaoSupport implements MlqUserDao {

    public List<MlqUser> allList(MlqUser mlqUser) {
        List<MlqUser> allList =this.getSqlSession()
                .selectList("integrationDemo2.dao.MlqUserDao.allList",mlqUser);
        return allList;
    }

}
