package mlq.mapper;

import mlq.bean.User;

public interface UserMapper {

    /**
     * 添加用户
     * @param user
     * @return
     */
    public int addUser(User user);


}
