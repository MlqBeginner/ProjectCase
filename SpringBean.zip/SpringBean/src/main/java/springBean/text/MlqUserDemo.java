package springBean.text;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import springBean.entity.MlqUser;

import java.util.ArrayList;
import java.util.List;

public class MlqUserDemo {

    //------------------------测试Bean：scope="singleton"作用域-------------------------//
    @Test
    public void textDemo1()
    {
        ApplicationContext context=
                new ClassPathXmlApplicationContext("springBean.xml");
       MlqUser mlqUser=(MlqUser)context.getBean("userSingleton");
       System.out.println("mlqUser"+mlqUser.getUserName());
       MlqUser mlqUser1=(MlqUser)context.getBean("userSingleton");
       System.out.println("mlqUser1"+mlqUser1.getUserName());
       mlqUser.setUserName("修改了");
       System.out.println("mlqUser"+mlqUser.getUserName());
       System.out.println("mlqUser1"+mlqUser1.getUserName());
       System.out.println("内存地址："+(mlqUser==mlqUser1));
    }

    //------------------------测试Bean：scope="prototype"作用域-------------------------//
    @Test
    public void textDemo2()
    {
        ApplicationContext context=
                new ClassPathXmlApplicationContext("springBean.xml");
        MlqUser mlqUser=(MlqUser)context.getBean("userPrototype");
        System.out.println("mlqUser"+mlqUser.getUserName());
        MlqUser mlqUser1=(MlqUser)context.getBean("userPrototype");
        System.out.println("mlqUser1"+mlqUser1.getUserName());
        mlqUser.setUserName("修改了");
        System.out.println("mlqUser"+mlqUser.getUserName());
        System.out.println("mlqUser1"+mlqUser1.getUserName());
        System.out.println("内存地址："+(mlqUser==mlqUser1));
    }


}
