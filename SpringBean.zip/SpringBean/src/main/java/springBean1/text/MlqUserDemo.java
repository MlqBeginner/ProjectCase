package springBean1.text;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import springBean.entity.MlqUser;
import springBean1.service.SveMlqUserDao;

import java.util.ArrayList;
import java.util.List;

public class MlqUserDemo {

    //------------------------使用注解测试Bean：scope="prototype"作用域-------------------------//
    @Test
    public void textDemo1()
    {
        ApplicationContext context=
                new ClassPathXmlApplicationContext("springBean1.xml");
        SveMlqUserDao sve= (SveMlqUserDao) context.getBean("sveMlqUserDaoImpl");
        SveMlqUserDao sve1= (SveMlqUserDao) context.getBean("sveMlqUserDaoImpl");
        System.out.println("内存地址："+(sve==sve1));

    }
    //------------------------使用注解测试Bean：scope="singleton"作用域-------------------------//
    @Test
    public void textDemo2()
    {
        ApplicationContext context=
                new ClassPathXmlApplicationContext("springBean1.xml");
        SveMlqUserDao sve= (SveMlqUserDao) context.getBean("sveMlqUserDaoImpls");
        SveMlqUserDao sve1= (SveMlqUserDao) context.getBean("sveMlqUserDaoImpls");
        System.out.println("内存地址："+(sve==sve1));

    }

}
