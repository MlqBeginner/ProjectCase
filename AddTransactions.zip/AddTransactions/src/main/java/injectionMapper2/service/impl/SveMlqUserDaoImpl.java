package injectionMapper2.service.impl;

import injectionMapper2.dao.MlqUserDao;
import injectionMapper2.entity.MlqUser;
import injectionMapper2.service.SveMlqUserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service("sveMlqUserDaoImpl")
public class SveMlqUserDaoImpl implements SveMlqUserDao
{

    @Autowired
    @Qualifier("mlqUserDao")
    private MlqUserDao mlqUserDao;

    public MlqUserDao getMlqUserDao() {
        return mlqUserDao;
    }

    public void setMlqUserDao(MlqUserDao mlqUserDao) {
        this.mlqUserDao = mlqUserDao;
    }

    public List<MlqUser> allList(MlqUser mlqUser) {
        return mlqUserDao.allList(mlqUser);
    }

    public int addUser(MlqUser mlqUser) {
        return mlqUserDao.addUser(mlqUser);
    }

    /**
     * 这里可以手动抛出异常来判断多条数据是否全部成功，或者全部失败
     * @param mlqUsers
     */
    public void addUsers(List<MlqUser> mlqUsers) {
        for (MlqUser user: mlqUsers
             ) {
            addUser(user);
            //throw new RuntimeException("手动抛出异常验证多条数据是否插入成功还是失败：请验证数据库中的数据");
        }
    }

}
