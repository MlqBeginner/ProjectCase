package annotatedTransaction.entity;

/**
 * 用户类
 */
public class MlqUser {

    private Integer uId;
    private String userName;
    private String userPwd;
    private String realName;

    public MlqUser(String userName, String userPwd, String realName) {
        this.userName = userName;
        this.userPwd = userPwd;
        this.realName = realName;
    }

    public MlqUser(Integer uId, String userName, String userPwd, String realName) {
        this.uId = uId;
        this.userName = userName;
        this.userPwd = userPwd;
        this.realName = realName;
    }

    public Integer getuId() {
        return uId;
    }

    public void setuId(Integer uId) {
        this.uId = uId;
    }

    public MlqUser() {
    }

    public Integer getUId() {
        return uId;
    }

    public void setUId(Integer uId) {
        this.uId = uId;
    }


    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }


    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }


    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

}
