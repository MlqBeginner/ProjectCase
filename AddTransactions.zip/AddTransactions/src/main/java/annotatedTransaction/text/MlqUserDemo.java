package annotatedTransaction.text;

import annotatedTransaction.entity.MlqUser;
import annotatedTransaction.service.SveMlqUserDao;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.List;

public class MlqUserDemo {

    //------------------------------查询用户信息-----------------------------------//
    @Test
    public void allUserList()
    {
        //伪造用户对象
        MlqUser mlqUser=new MlqUser(20180001,"MLQ","123","马立强");
        //实例ApplicationContext
        ApplicationContext context=
                new ClassPathXmlApplicationContext("AnnotatedTransactions.xml");
        //输出所有BeanId名称
        String[] beanDefinitionNames = context.getBeanDefinitionNames();
        for (String item:beanDefinitionNames
                ) {
            System.out.println(item);
        }
        //获取实例对象
        SveMlqUserDao userMapper = (SveMlqUserDao)context.getBean("sveMlqUserDaoImpl");
        //调用方法查询信息
        List<MlqUser> mlqUsers = userMapper.allList(mlqUser);
        for (MlqUser item : mlqUsers)
        {
            System.out.println("用户名："+item.getUserName());
        }
    }
    //------------------------------添加单个用户信息-----------------------------------//
    @Test
    public void allUser()
    {
        //伪造用户对象
        MlqUser mlqUser=new MlqUser("LSY","123","马立强");
        //实例ApplicationContext
        ApplicationContext context=
                new ClassPathXmlApplicationContext("AnnotatedTransactions.xml");
        //获取实例对象
        SveMlqUserDao userMapper = (SveMlqUserDao) context.getBean("sveMlqUserDaoImpl");
        //调用添加方法
        int i = userMapper.addUser(mlqUser);
        System.out.println("添加成功："+i);
    }

    //------------------------------添加多个用户信息-----------------------------------//
    @Test
    public void allUsers()
    {
        //伪造用户对象
        MlqUser mlqUser=new MlqUser("LSY","123","马立强");
        //实例ApplicationContext
        ApplicationContext context=
                new ClassPathXmlApplicationContext("AnnotatedTransactions.xml");
        //获取实例对象
        SveMlqUserDao userMapper = (SveMlqUserDao) context.getBean("sveMlqUserDaoImpl");
        //调用多个用户添加方法
        List<MlqUser> users=new ArrayList<MlqUser>();
        users.add(mlqUser);
        users.add(mlqUser);
        userMapper.addUsers(users);
        //请查看数据库进行对比
    }




}
